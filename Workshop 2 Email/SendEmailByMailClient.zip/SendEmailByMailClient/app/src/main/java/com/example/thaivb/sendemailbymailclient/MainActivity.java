package com.example.thaivb.sendemailbymailclient;

import android.content.Intent;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final com.google.android.material.textfield.TextInputLayout lblMailTo = findViewById(R.id.lblMailTo);
        final EditText edtMailTo = findViewById(R.id.edtMailTo);

        final com.google.android.material.textfield.TextInputLayout lblSubject = findViewById(R.id.lblSubject);
        final EditText edtSubject = findViewById(R.id.edtSubject);

        final TextInputLayout lblBody = findViewById(R.id.lblBody);
        final EditText edtBody = findViewById(R.id.edtBody);

        Button cmdSend = findViewById(R.id.cmdSend);
        cmdSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtMailTo.getText().toString().trim().equals("")){
                    lblMailTo.setHint("กรุณาป้อนเมล์ลูกค้าก่อน !!!");
                }
                if (edtSubject.getText().toString().trim().equals("")){
                    lblSubject.setHint("กรุณาป้อนหัวข้อเมล์ก่อน !!!");
                }
                if (edtBody.getText().toString().trim().equals("")){
                    lblBody.setHint("กรุณาป้อนเนื้อหาในเมล์ !!!");
                }

                Intent it = new Intent(Intent.ACTION_SEND);
                it.putExtra(Intent.EXTRA_EMAIL, new String[]{edtMailTo.getText().toString().trim()});
                it.putExtra(Intent.EXTRA_SUBJECT, edtSubject.getText().toString().trim());
                it.putExtra(Intent.EXTRA_TEXT, edtBody.getText().toString().trim());
                it.setType("message/rfc822");

                startActivity(Intent.createChooser(it, "กรุณาเลือกตัวส่ง E-mail"));
            }
        });

        Button cmdClear = findViewById(R.id.cmdClear);
        cmdClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtMailTo.setText("");
                edtSubject.setText("");
                edtBody.setText("");
            }
        });
    }
}
