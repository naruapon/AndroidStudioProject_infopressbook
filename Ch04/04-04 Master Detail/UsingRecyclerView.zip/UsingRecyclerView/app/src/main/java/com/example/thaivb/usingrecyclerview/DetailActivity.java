package com.example.thaivb.usingrecyclerview;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Intent it = this.getIntent();
        int CurrentCover = it.getExtras().getInt("selectedCover");
        String CurrentTitle = it.getExtras().getString("selectedTitle");

        ImageView imgCurrentCover = findViewById(R.id.imgCurrentCover);
        imgCurrentCover.setImageResource(CurrentCover);
        TextView tvCurrentTitle = findViewById(R.id.tvCurrentTitle);
        tvCurrentTitle.setText(CurrentTitle);
    }
}
