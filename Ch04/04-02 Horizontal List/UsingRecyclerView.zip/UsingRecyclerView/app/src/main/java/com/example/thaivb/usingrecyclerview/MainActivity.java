package com.example.thaivb.usingrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.thaivb.usingrecyclerview.adapter.adt_rv_cardview;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        androidx.recyclerview.widget.RecyclerView rv = findViewById(R.id.recyclerview);
        rv.setHasFixedSize(true);
        androidx.recyclerview.widget.RecyclerView.LayoutManager lm = new androidx.recyclerview.widget.LinearLayoutManager(MainActivity.this, androidx.recyclerview.widget.LinearLayoutManager.HORIZONTAL, false);

        rv.setLayoutManager(lm);
        androidx.recyclerview.widget.RecyclerView.Adapter adt = new adt_rv_cardview();
        rv.setAdapter(adt);
    }
}
