package com.example.thaivb.usingrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.thaivb.usingrecyclerview.adapter.adt_rv_cardview;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView rv = findViewById(R.id.recyclerview);
        rv.setHasFixedSize(true);
        androidx.recyclerview.widget.RecyclerView.LayoutManager lm = new GridLayoutManager(MainActivity.this, 3);
        rv.setLayoutManager(lm);
        androidx.recyclerview.widget.RecyclerView.Adapter adt = new adt_rv_cardview();
        rv.setAdapter(adt);
    }
}
