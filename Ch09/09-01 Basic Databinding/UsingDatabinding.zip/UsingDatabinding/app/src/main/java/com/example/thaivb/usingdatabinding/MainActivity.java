package com.example.thaivb.usingdatabinding;

import androidx.databinding.DataBindingUtil;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.thaivb.usingdatabinding.databinding.ActivityMainBinding;
import com.example.thaivb.usingdatabinding.model.Products;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Products p = new Products();
        p.setProductID("001");
        p.setProductName("Android Programming");
        UpdateProducts(p);

        Button cmdEdit = findViewById(R.id.cmdEdit);
        cmdEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UpdateUI(view);
            }
        });
    }

    public void UpdateUI(View view) {
        Products p = new Products();
        p.setProductID("111");
        p.setProductName("Android Programming 9");
        UpdateProducts(p);
    }

    private void UpdateProducts(Products p) {
        ActivityMainBinding bd = DataBindingUtil.setContentView(this, R.layout.activity_main);
        bd.setProducts(p);
    }
}
