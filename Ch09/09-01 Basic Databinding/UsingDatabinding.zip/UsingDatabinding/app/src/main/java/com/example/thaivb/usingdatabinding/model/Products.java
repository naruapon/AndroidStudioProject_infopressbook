package com.example.thaivb.usingdatabinding.model;

public class Products {
    private String ProductID;
    private String ProductName;

    public String getProductID() {
        return ProductID;
    }

    public void setProductID(String productID) {
        ProductID = productID;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }
}

