package com.example.thaivb.usingsharedpreferences;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    SharedPreferences pref;
    EditText edtData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pref = getSharedPreferences("prefData", Context.MODE_PRIVATE);
        final SharedPreferences.Editor edt;
        edtData = findViewById(R.id.edtData);

        Button cmdSave = findViewById(R.id.cmdSave);
        cmdSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtData.getText().toString().trim())){
                    return;
                }

                SharedPreferences.Editor edit = pref.edit();
                edit.putString("CurrentData", edtData.getText().toString().trim());
                edit.apply();
                ClearData();
                Toast.makeText(MainActivity.this, "บันทึกข้อมูลลง Shared Preferences แล้ว", Toast.LENGTH_LONG).show();
            }
        });

        Button cmdRead = findViewById(R.id.cmdRead);
        cmdRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ReadData();
            }
        });

        Button cmdClear = findViewById(R.id.cmdClear);
        cmdClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ClearData();
            }
        });

        Button cmdDelete = findViewById(R.id.cmdDelete);
        cmdDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor edit = pref.edit();
                edit.remove("CurrentData");
                edit.apply();

                ClearData();
                Toast.makeText(MainActivity.this, "ลบข้อมูลใน Shared Preferences แล้ว", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void ReadData(){
        String str = pref.getString("CurrentData", "ไม่มีข้อมูล");
        edtData.setText(str);
    }

    private void ClearData(){
        edtData.setText("");
    }
}
