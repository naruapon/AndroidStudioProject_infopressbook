package com.example.thaivb.usingtextinputlayout;

import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextInputLayout lblUserName = findViewById(R.id.lblUserName);
        final EditText edtUserName = findViewById(R.id.edtUserName);

        final TextInputLayout lblAddress = findViewById(R.id.lblAddress);
        final EditText edtAddress = findViewById(R.id.edtAddress);

        Button cmdSave = findViewById(R.id.cmdSave);
        cmdSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtUserName.getText().toString().trim().equals("")){
                    lblUserName.setHint("กรุณาป้อนชื่อ-สกุลก่อน !!!");
                }
                if (edtAddress.getText().toString().trim().equals("")){
                    lblAddress.setHint("กรุณาป้อนที่อยู่ก่อน !!!");
                }
            }
        });
    }
}
