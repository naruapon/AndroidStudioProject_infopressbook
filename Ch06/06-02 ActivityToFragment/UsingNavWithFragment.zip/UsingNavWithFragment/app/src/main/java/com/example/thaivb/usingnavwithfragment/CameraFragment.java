package com.example.thaivb.usingnavwithfragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class CameraFragment extends androidx.fragment.app.Fragment {
    public CameraFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_camera, container, false);

        TextView tvFragment =  v.findViewById(R.id.tvFragment);
        String str = this.getArguments().getString("CurrentData");
        tvFragment.setText(str + " แสดงใน Fragment");

        return v;
    }
}
