package com.example.thaivb.usingbottomnavigationwithfragment;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.appcompat.app.AppCompatActivity;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
               switch (item.getItemId()) {
                case R.id.navigation_home:
                    HomeFragmentLoading();
                    return true;
                case R.id.navigation_dashboard:
                    DashboardFragmentLoading();
                    return true;
                case R.id.navigation_notifications:
                    NotificationFragmentLoading();
                    return true;
            }
            return false;
        }
    };

    private void HomeFragmentLoading() {
        HomeFragment fm = new HomeFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.maincontent, fm);
        ft.commit();
    }

    private void DashboardFragmentLoading() {
        DashboardFragment fm = new DashboardFragment();
        androidx.fragment.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.maincontent, fm);
        ft.commit();
    }

    private void NotificationFragmentLoading() {
        NotificationFragment fm = new NotificationFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.maincontent, fm);
        ft.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        HomeFragmentLoading();

        com.google.android.material.bottomnavigation.BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }
}
