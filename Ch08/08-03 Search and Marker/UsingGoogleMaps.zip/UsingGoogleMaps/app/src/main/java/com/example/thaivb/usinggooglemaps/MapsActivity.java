package com.example.thaivb.usinggooglemaps;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends androidx.fragment.app.FragmentActivity implements OnMapReadyCallback {
    private GoogleMap mMap;
    double Lat = 13.803742;
    double Lng = 100.554603;
    private static final int LOCATION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        int status = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(MapsActivity.this);
        if (status == ConnectionResult.SUCCESS){
            if (ActivityCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MapsActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            }
        }
        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(MapsActivity.this);

        Button cmdClear = findViewById(R.id.cmdClear);
        cmdClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMap.clear();
            }
        });

        Button cmdSearch = findViewById(R.id.cmdSearch);
        cmdSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText edtSearch = findViewById(R.id.edtSearch);
                String q = edtSearch.getText().toString().trim();

                if (q != null && !q.equals("")) {
                    Geocoder geo = new Geocoder(MapsActivity.this, Locale.getDefault());
                    try {
                        List<Address> addLists = geo.getFromLocationName(q, 7);
                        if (addLists.size() > 0) {
                            mMap.clear();

                            Address add = null;
                            LatLng CurrentAddress = null;
                            for (int i = 0; i < addLists.size(); i++) {
                                add = (Address) addLists.get(i);
                                CurrentAddress = new LatLng(add.getLatitude(), add.getLongitude());

                                String str = "";
                                for (int j = 0; j < add.getMaxAddressLineIndex(); j++){
                                    str = str + add.getAddressLine(j) + "\n";
                                }

                                Marker m = mMap.addMarker(new MarkerOptions()
                                        .position(CurrentAddress)
                                        .title(add.getAddressLine(0) + " (Lat : " + add.getLatitude()
                                                + ") (Lng : " + add.getLongitude() + ")")
                                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                                        .snippet(str));
                            }

                            CameraPosition cam = new CameraPosition.Builder()
                                    .target(CurrentAddress)
                                    .zoom(5)
                                    .build();
                            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cam));
                        } else {
                            Toast.makeText(getBaseContext(), "ไม่พบที่อยู่ตามที่คุณระบุ!!!", Toast.LENGTH_LONG).show();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_REQUEST_CODE: {
                if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "ไม่สามารถใช้งานแผนที่ได้", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng jj = new LatLng(Lat, Lng);

        if (mMap != null){
            if (ActivityCompat.checkSelfPermission(MapsActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MapsActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
            } else {
                mMap.setMyLocationEnabled(true);
                mMap.getUiSettings().setZoomControlsEnabled(true);
            }
        }
        mMap.addMarker(new MarkerOptions().position(jj).title("จตุจักร"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(jj));
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                String strAddress = "Lat : " + String.valueOf(latLng.latitude) + " "
                        + "Lng : " + String.valueOf(latLng.longitude);
                MarkerOptions m = new MarkerOptions();
                m.position(latLng);
                m.title(strAddress);
                mMap.addMarker(m);
            }
        });
    }
}
