package com.example.thaivb.basicroom.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface CustomerDAO {
    @Query("SELECT * FROM Customer")
    List<Customer> getAllCustomers();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void create(Customer customer);
}

