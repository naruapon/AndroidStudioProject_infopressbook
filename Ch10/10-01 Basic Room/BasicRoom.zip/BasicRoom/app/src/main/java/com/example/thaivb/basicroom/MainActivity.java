package com.example.thaivb.basicroom;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.example.thaivb.basicroom.adapter.adt_rv_customer;
import com.example.thaivb.basicroom.db.AppDatabase;
import com.example.thaivb.basicroom.db.Customer;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        com.google.android.material.floatingactionbutton.FloatingActionButton fab = findViewById(R.id.fab);
        RecyclerView rv = findViewById(R.id.rvCustomerLists);

        RecyclerView.Adapter adt = new adt_rv_customer(getCustomerLists());
        rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        rv.setAdapter(adt);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, CreateCustomer.class));
            }
        });
    }

    private List<Customer> getCustomerLists() {
        return AppDatabase.getInstance(this).customerDAO().getAllCustomers();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        AppDatabase.desInstance();
        super.onDestroy();
    }
}
