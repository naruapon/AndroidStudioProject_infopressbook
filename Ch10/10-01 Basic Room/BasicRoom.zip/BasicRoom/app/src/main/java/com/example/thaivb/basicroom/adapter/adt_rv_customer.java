package com.example.thaivb.basicroom.adapter;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.thaivb.basicroom.R;
import com.example.thaivb.basicroom.db.Customer;

import java.util.List;

public class adt_rv_customer extends androidx.recyclerview.widget.RecyclerView.Adapter<adt_rv_customer.ViewHolder>  {
    private List<Customer> customers;

    public adt_rv_customer(List<Customer> c) {
        this.customers = c;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_item_customer, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvFullName.setText(customers.get(position).getFullName());
        holder.tvAddress.setText(customers.get(position).getAddress());
    }

    @Override
    public int getItemCount() {
        return customers.size();
    }

    public class ViewHolder extends androidx.recyclerview.widget.RecyclerView.ViewHolder {
        public TextView tvFullName;
        public TextView tvAddress;

        public ViewHolder(View itemView) {
            super(itemView);

            tvFullName = itemView.findViewById(R.id.tvFullName);
            tvAddress = itemView.findViewById(R.id.tvAddress);
        }
    }
}
