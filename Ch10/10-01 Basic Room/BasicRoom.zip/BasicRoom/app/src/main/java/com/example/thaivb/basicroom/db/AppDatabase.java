package com.example.thaivb.basicroom.db;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

@Database(entities = {Customer.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static final String DATABASE_NAME = "myshop";
    private static AppDatabase db;

    public abstract CustomerDAO customerDAO();

    public static AppDatabase getInstance(Context ctx) {
        if (db == null) {
            db = Room.databaseBuilder(ctx.getApplicationContext(),
                    AppDatabase.class, DATABASE_NAME)
                    .allowMainThreadQueries()
                    .build();
        }
        return db;
    }

    public static void desInstance() {
        db = null;
    }
}

