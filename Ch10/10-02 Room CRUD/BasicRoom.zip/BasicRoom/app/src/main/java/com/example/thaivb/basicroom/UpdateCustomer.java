package com.example.thaivb.basicroom;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.thaivb.basicroom.db.AppDatabase;
import com.example.thaivb.basicroom.db.Customer;

import java.util.Objects;

public class UpdateCustomer extends AppCompatActivity {
    Customer c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_customer);

        Intent it = getIntent();
        c = (Customer) Objects.requireNonNull(it.getExtras()).getSerializable("customer");

        final EditText edtFullName = findViewById(R.id.edtFullName);
        final EditText edtAddress = findViewById(R.id.edtAddress);

        edtFullName.setText(c.getFullName().trim());
        edtAddress.setText(c.getAddress().trim());

        Button cmdUpdate = findViewById(R.id.cmdUpdate);
        cmdUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtFullName.getText())){
                    return;
                }

                if (TextUtils.isEmpty(edtAddress.getText())){
                    return;
                }

                c.setFullName(edtFullName.getText().toString().trim());
                c.setAddress(edtAddress.getText().toString().trim());
                AppDatabase.getInstance(UpdateCustomer.this).customerDAO().update(c);
                finish();
            }
        });
    }
}
