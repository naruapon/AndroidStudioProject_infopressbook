package com.example.thaivb.basicroom;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.thaivb.basicroom.db.AppDatabase;
import com.example.thaivb.basicroom.db.Customer;

public class CreateCustomer extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_customer);

        final EditText edtFullName = findViewById(R.id.edtFullName);
        final EditText edtAddress = findViewById(R.id.edtAddress);
        Button cmdSave = findViewById(R.id.cmdSave);
        cmdSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strFullName = edtFullName.getText().toString().trim();
                String strAddress = edtAddress.getText().toString().trim();

                if (TextUtils.isEmpty(strFullName)){
                    return;
                }

                if (TextUtils.isEmpty(strAddress)){
                    return;
                }

                Customer c = new Customer();
                c.setFullName(strFullName);
                c.setAddress(strAddress);

                AppDatabase.getInstance(CreateCustomer.this).customerDAO().create(c);

                edtFullName.getText().clear();
                edtAddress.requestFocus();
                startActivity(new Intent(CreateCustomer.this, MainActivity.class));
            }
        });
        Button cmdClear = findViewById(R.id.cmdClear);
        cmdClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtFullName.setText("");
                edtAddress.setText("");
            }
        });
    }

    @Override
    protected void onDestroy() {
        AppDatabase.desInstance();
        super.onDestroy();
    }
}
