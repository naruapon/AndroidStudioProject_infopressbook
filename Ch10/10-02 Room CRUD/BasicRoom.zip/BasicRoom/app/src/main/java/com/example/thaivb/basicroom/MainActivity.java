package com.example.thaivb.basicroom;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.example.thaivb.basicroom.adapter.adt_rv_customer;
import com.example.thaivb.basicroom.db.AppDatabase;
import com.example.thaivb.basicroom.db.Customer;

import java.util.List;

public class MainActivity extends AppCompatActivity implements adt_rv_customer.OnCustomerItemClick {
    private List<Customer> customers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        com.google.android.material.floatingactionbutton.FloatingActionButton fab = findViewById(R.id.fab);
        RecyclerView rv = findViewById(R.id.rvCustomerLists);

        RecyclerView.Adapter adt = new adt_rv_customer(getCustomerLists(), MainActivity.this);
        rv.setLayoutManager(new androidx.recyclerview.widget.LinearLayoutManager(MainActivity.this));
        rv.setAdapter(adt);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, CreateCustomer.class));
            }
        });
    }

    private List<Customer> getCustomerLists() {
        customers = AppDatabase.getInstance(this).customerDAO().getAllCustomers();
        return customers;
    }

    @Override
    public void onCustomerClick(final int pos) {
        new AlertDialog.Builder(MainActivity.this)
                .setTitle("คุณต้องการทำอะไร?")
                .setItems(new String[]{"ลบข้อมูลลูกค้า", "แก้ไขข้อมูลลูกค้า"},
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                switch (i){
                                    case 0:
                                        AppDatabase.getInstance(MainActivity.this).customerDAO().delete(customers.get(pos));
                                        customers.remove(pos);
                                        recreate();
                                        break;
                                    case 1:
                                        startActivityForResult(new Intent(MainActivity.this,
                                                        UpdateCustomer.class).putExtra("customer",customers.get(pos)), 200);
                                        break;
                                }
                            }
                        }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 200){
            recreate();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        AppDatabase.desInstance();
        super.onDestroy();
    }
}
