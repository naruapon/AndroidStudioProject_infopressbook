package com.example.thaivb.currentposition;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import androidx.annotation.NonNull;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_LOCATION_CODE = 200;
    FusedLocationProviderClient locClient;

    double CurrentLat = 0.0;
    double CurrentLng = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int locPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION);
                if (locPermission == PackageManager.PERMISSION_GRANTED) {
                    getCurrentPosition();
                }
                reqAccessLocation();
            }
        });

        Button cmdGoToMaps = findViewById(R.id.cmdGoToMaps);
        cmdGoToMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(MainActivity.this, MapsActivity.class);
                MainActivity.this.startActivity(it);
            }
        });
    }

    private void reqAccessLocation() {
        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_LOCATION_CODE);
    }

    private void getCurrentPosition() {
        locClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);
        int locPermission = ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION);
        if (locPermission == PackageManager.PERMISSION_GRANTED) {
            locClient.getLastLocation().addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    CurrentLat = location.getLatitude();
                    CurrentLng = location.getLongitude();

                    TextView tvLat = findViewById(R.id.tvLat);
                    TextView tvLng = findViewById(R.id.tvLng);

                    tvLat.setText("ละติจูด : " + String.valueOf(CurrentLat));
                    tvLng.setText("ลองติจูด : " + String.valueOf(CurrentLng));
                }
            });
        } else {
            reqAccessLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 200) {
            getCurrentPosition();
        }
    }
}
