package com.example.thaivb.basicmenu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (item.getItemId()) {
            case R.id.mnuHome:
                //โค้ด JAVA ให้ทำอะไรต่อ
                break;
            case R.id.mnuOption:
                //โค้ด JAVA ให้ทำอะไรต่อ
                break;
            case R.id.mnuHelp:
                //โค้ด JAVA ให้ทำอะไรต่อ
                break;
        }

        Toast.makeText(MainActivity.this,"เมนู" + item.getTitle() + " ถูกเลือก",
                Toast.LENGTH_LONG).show();
        return true;
    }
}
